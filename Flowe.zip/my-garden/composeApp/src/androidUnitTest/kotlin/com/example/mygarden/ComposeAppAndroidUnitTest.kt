package com.example.mygarden

import kotlin.test.Test
import kotlin.test.assertEquals

class ComposeAppAndroidUnitTest {

    @Test
    fun example() {
        assertEquals(3, 1 + 2)
    }
}