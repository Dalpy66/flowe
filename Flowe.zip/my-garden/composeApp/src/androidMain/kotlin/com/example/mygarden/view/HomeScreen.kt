package com.example.mygarden.view

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mygarden.model.database.DatabaseData
import com.example.mygarden.view.mainarea.AlertSection
import com.example.mygarden.view.mainarea.DataList
import com.example.mygarden.view.mainarea.SwipeCardContent
import com.example.mygarden.view.weather.WeatherTopBar
import com.example.mygarden.viewmodel.HomeViewModel
import com.example.mygarden.viewmodel.WeatherViewModel
import com.example.mygarden.viewmodel.mapStateIcon


@Preview(
    showBackground = true
)
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel(), weatherViewModel: WeatherViewModel = viewModel()) {
    val pageState = rememberPagerState(pageCount = { 3 })

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        WeatherTopBar(
            weather = weatherViewModel
        )

        HorizontalPager(
            state = pageState,
            modifier = Modifier.fillMaxWidth()
                .fillMaxHeight(0.5f)
        ) { page ->
            SwipeCardContent(
                page = page,
                getImageForPage = { mapStateIcon("buono") }
            )
            AlertSection(
                page = page
            )
        }

        val currentPage = pageState.currentPage
        val data by viewModel.getDataForTab(currentPage).collectAsState(
            initial = emptyList()
        )

        DataList(data = data)
    }
}