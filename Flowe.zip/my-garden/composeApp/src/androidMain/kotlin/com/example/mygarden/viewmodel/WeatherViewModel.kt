package com.example.mygarden.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mygarden.model.weather.WeatherApi
import com.example.mygarden.model.weather.WeatherRepository
import com.example.mygarden.model.weather.WeatherData
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class WeatherViewModel : ViewModel() {
    private val api = Retrofit.Builder()
        .baseUrl("https://api.openweathermap.org/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(WeatherApi::class.java)

    private val repository = WeatherRepository(api)
    var weather by mutableStateOf<WeatherData?>(null)
        private set

    fun loadWeather(lat : Double = 45.54034686750178, lon : Double = 11.545242876772134) {
        viewModelScope.launch {
            weather = repository.fetchWeather(lat, lon)
        }
    }
}