package com.example.mygarden.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.mygarden.model.database.DatabaseApi
import com.example.mygarden.model.database.DatabaseData
import com.example.mygarden.model.database.DatabaseRepository
import com.example.mygarden.model.database.LoginData
import com.example.mygarden.view.mainarea.MacroArea
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class DatabaseViewModel : ViewModel() {
    private val baseUrl = System.getenv("DATABASE_BASE_URL")
    private val api = Retrofit.Builder()
        .baseUrl(baseUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(DatabaseApi::class.java)

    private val repository = DatabaseRepository(api)

    var loginData by mutableStateOf<LoginData?>(null)


    fun toUiState(data: DatabaseData) : MacroArea{
        data.name
        mapStateIcon(data.state)
        TODO("Provide the return value")
    }
}