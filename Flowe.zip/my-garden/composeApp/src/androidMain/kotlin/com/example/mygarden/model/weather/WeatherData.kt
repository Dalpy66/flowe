package com.example.mygarden.model.weather

import com.google.gson.annotations.SerializedName

data class WeatherData(
    val main: Main,
    val weather: List<Weather>,
    val wind: Wind,
    val rain: Rain?
)

data class Main(
    val temp: Double,
    val humidity: Int
)

data class Weather(
    val main: String,
    val icon: String
)

data class Rain(
    @SerializedName("1h")
    val oneHour: Double?
)

data class Wind(
    val speed: Double,
    val deg: Int
)