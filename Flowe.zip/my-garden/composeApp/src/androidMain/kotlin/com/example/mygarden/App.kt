package com.example.mygarden

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.safeContentPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModel
import com.example.mygarden.ui.theme.AppTheme
import com.example.mygarden.view.HomeScreen
import com.example.mygarden.viewmodel.HomeViewModel
import org.jetbrains.compose.resources.painterResource

import mygarden.composeapp.generated.resources.Res
import mygarden.composeapp.generated.resources.compose_multiplatform

@Composable
@Preview(
    uiMode = Configuration.UI_MODE_NIGHT_YES
)
fun App() {
    AppTheme {
        HomeScreen()
    }
}