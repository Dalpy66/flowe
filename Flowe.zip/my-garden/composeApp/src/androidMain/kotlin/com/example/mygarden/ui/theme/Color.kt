package com.example.mygarden.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF495924)
val GreenOnPrimary = Color(0xFFFFFFFF)
val GreenSecondary = Color(0xFFA7AA64)
val OrangeTertiary = Color(0xFFE9975A)
val WhiteBackground = Color(0xFFC5C7C2)

val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)



// Varianti Dark Mode
val GreenPrimaryDark = Color(0xFFA7AA64)
val GreenOnPrimaryDark = Color(0xFF000000)

val GreenSecondaryDark = Color(0xFF495924)

val RedTertieryDark = Color(0xFFB63E23)

val BackgroundDark = Color(0xFF1A1C19)