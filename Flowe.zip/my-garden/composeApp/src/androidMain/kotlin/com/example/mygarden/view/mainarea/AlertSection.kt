package com.example.mygarden.view.mainarea

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun AlertSection(page: Int){
    val alertText = when (page) {
        1 -> "Primo Sensore"
        2 -> "Secondo Sensore"
        else -> "Il mio terreno"
    }

    Box(
        modifier = Modifier.fillMaxWidth()
            .padding(12.dp)
    ) {
        Text(
            text = alertText,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimary
        )
    }
}

@Preview
@Composable
fun AlertSectionPreview() {
    AlertSection(page = 1)
}