package com.example.mygarden.view.weather

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mygarden.viewmodel.WeatherViewModel

@Composable
fun WeatherTopBar( weather: WeatherViewModel?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        AsyncImage(
            model = "https://openweathermap.org/img/wn/${weather?.weather?.weather?.firstOrNull()?.icon ?: "10d"}@2x.png",
            contentDescription = null,
            modifier = Modifier
                    .size(64.dp) // dimensione controllata
                .   clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Fit
        )
        Text(
            text = weather?.weather?.main?.temp?.let { "$it°C" } ?: "--°C",
            color = MaterialTheme.colorScheme.onPrimary
        )

        Text(
            text = weather?.weather?.main?.humidity?.let { "$it%" } ?: "--%",
            color = MaterialTheme.colorScheme.onPrimary
        )

        Text(
            text = weather?.weather?.wind?.speed?.let { "$it km/h" } ?: "--km/h",
            color = MaterialTheme.colorScheme.onPrimary
        )

        LaunchedEffect(Unit) { weather?.loadWeather() }

    }
}

@Preview(showBackground = true)
@Composable
fun WeatherTopBarPreview() {
    WeatherTopBar(null)
}