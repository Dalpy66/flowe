package com.example.mygarden.model.database

import com.example.mygarden.R

data class DatabaseData (
    val name: String,
    val description: String,
    val state: String
    //TODO
)

data class DatabaseItem(
    val title: String,
    val value: String
)

data class LoginData (
    val id: Int,
    val nome: String,
    val email: String,
    val idHub: String,
    val latitudeHub: Double,
    val longitudeHub: Double,
    val idSensori: List<Int>
)

data class StoricoData(
    val temperatura: Double,
    val umidita: Double,
    val conducibilita: Int,
    val ph: Double,
    val azoto: Int,
    val fosforo: Int,
    val potassio: Int,
    val stato: StatoPianta
)

data class SensoreData(
    val idSensore: Int,
    val codiceSensore: String,
    val latitudine: Double,
    val longitudine: Double,
    val nomePianta: String,
    val statoPianta: StatoPianta,
    val iconaStato: Int = mapStateIcon(statoPianta.stato),
    val report: String,
    val storicoMisureDTOList: List<StoricoData>

)

enum class StatoPianta(val stato: String){
    SANO("sano"),
    BUONO("buono"),
    ALLERTA("allerta"),
    CRITICO("critico")
}

fun mapStateIcon(stato: String?) : Int {
    return when (stato) {
        "sano" -> R.drawable.sano
        "buono" -> R.drawable.buono
        "allerta" -> R.drawable.allerta
        "critico" -> R.drawable.critico
        else -> R.drawable.buono
    }
}
