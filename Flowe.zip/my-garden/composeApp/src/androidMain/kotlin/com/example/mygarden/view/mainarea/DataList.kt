package com.example.mygarden.view.mainarea

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.mygarden.model.database.DatabaseItem

@Composable
fun DataList(data: List<DatabaseItem>) {
    LazyColumn (
        modifier = Modifier.fillMaxSize()
    ) {
        items(data) {
            item -> ItemRow(item)

    }
}


}