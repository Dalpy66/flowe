package com.example.mygarden.model.database

class DatabaseRepository(private val api: DatabaseApi) {
    val apiKey = System.getenv("DATABASE_API_KEY")

    suspend fun login() = api.getLogin()
    suspend fun getSensore(idSensore: Int) = api.getSensore(idSensore)

    fun getUltimoDato(sensore: SensoreData) : StoricoData? {
        return sensore.storicoMisureDTOList.lastOrNull()
    }
    fun getStoricoSensore(sensore: SensoreData) : List<StoricoData> {
        return sensore.storicoMisureDTOList
    }

    suspend fun getMediaStorico(loginData: LoginData) : StoricoData {
        var temperatura = 0.0
        var umidita = 0.0
        var conducibilita = 0
        var ph = 0.0
        var azoto = 0
        var fosforo = 0
        var potassio = 0
        var counter = 0
        var stato : StatoPianta = StatoPianta.SANO

        loginData.idSensori.forEach {
            var sensore = getSensore(it)
            if (sensore.statoPianta > stato) {
                stato = sensore.statoPianta
            }

            sensore.storicoMisureDTOList.firstOrNull() { storicoData ->
                temperatura += storicoData.temperatura
                umidita += storicoData.umidita
                conducibilita += storicoData.conducibilita
                ph += storicoData.ph
                azoto += storicoData.azoto
                fosforo += storicoData.fosforo
                potassio += storicoData.potassio
                counter++

                true
            }
        }

        temperatura /= counter
        umidita /= counter
        conducibilita /= counter
        ph /= counter
        azoto /= counter
        fosforo /= counter
        potassio /= counter


        return StoricoData(
            temperatura = temperatura,
            umidita = umidita,
            conducibilita = conducibilita,
            ph = ph,
            azoto = azoto,
            fosforo = fosforo,
            potassio = potassio,
            stato = stato
        )
    }
}