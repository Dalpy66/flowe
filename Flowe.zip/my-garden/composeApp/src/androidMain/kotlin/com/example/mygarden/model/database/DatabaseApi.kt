package com.example.mygarden.model.database

import retrofit2.http.GET
import retrofit2.http.Path

interface DatabaseApi {
    @GET("utenti/login/1")
    suspend fun getLogin() : LoginData

    @GET("storico-misure/storico/{idSensore}")
    suspend fun getSensore(
        @Path("idSensore") idSensore : Int
    ) : SensoreData

}