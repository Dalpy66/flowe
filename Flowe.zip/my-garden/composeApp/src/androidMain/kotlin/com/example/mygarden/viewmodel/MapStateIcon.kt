package com.example.mygarden.viewmodel

import com.example.mygarden.R

fun mapStateIcon(iconCode: String?) : Int {
    return when (iconCode) {
        "sano" -> R.drawable.sano
        "buono" -> R.drawable.buono
        "allerta" -> R.drawable.allerta
        "critico" -> R.drawable.critico
        else -> R.drawable.buono
    }
}