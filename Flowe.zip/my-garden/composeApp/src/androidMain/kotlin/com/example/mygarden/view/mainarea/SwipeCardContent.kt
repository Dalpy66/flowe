package com.example.mygarden.view.mainarea

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mygarden.viewmodel.mapStateIcon

@Composable
fun SwipeCardContent(page: Int, getImageForPage: (Int) -> Int) {
    Box(
        modifier = Modifier.fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxSize(),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                Image(
                    painter = painterResource(id = getImageForPage(page)),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth()
                        ,
                    contentScale = ContentScale.Fit

                )

                AlertSection(page = page)
            }
        }
    }
}

@Preview
@Composable
fun SwipeCardContentPreview() {
    SwipeCardContent(page = 0) { mapStateIcon("buono") }
}