package com.example.mygarden.model.weather


class WeatherRepository(private val api: WeatherApi) {
    val apiKey : String = System.getenv("WEATHER_API_KEY") ?: "0ff94aaab1292b8fc22783811839ab58"

    suspend fun fetchWeather(latitude: Double, longitude: Double) =
        api.getWeather(latitude, longitude, apiKey)
}


