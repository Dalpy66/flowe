package com.example.mygarden.viewmodel

import androidx.lifecycle.ViewModel
import com.example.mygarden.model.database.DatabaseItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class HomeViewModel : ViewModel() {
    fun getDataForTab(tab: Int) : Flow<List<DatabaseItem>> {
        return flow {
            emit(
                when(tab) {
                    0 -> listOf(DatabaseItem("Item 1", "Description 1"))
                    1 -> listOf(DatabaseItem("Item 2", "Description 2"))
                    2 -> listOf(DatabaseItem("Item 3", "Description 3"))
                    else -> emptyList()
                }
            )
        }

    }
}

