package com.example.mygarden.view.mainarea

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mygarden.model.database.DatabaseItem

@Composable
fun ItemRow(item: DatabaseItem) {
    Row (modifier = Modifier.fillMaxWidth()
        .padding(16.dp)
    ) {
        Text(
            text = item.title,
            color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = item.value,
            color = MaterialTheme.colorScheme.onBackground)
    }
}

@Preview(showBackground = true)
@Composable
fun ItemRowPreview() {
    ItemRow(item = DatabaseItem(title = "Title", value = "Value"))
}