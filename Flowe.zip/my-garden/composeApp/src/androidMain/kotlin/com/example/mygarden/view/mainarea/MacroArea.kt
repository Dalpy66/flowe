package com.example.mygarden.view.mainarea

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

data class MacroArea(
    val title: String,
    val message: String,
    val iconRes: Int,
    val content: @Composable () -> Unit
)